class Weapon {
    constructor(name, damage, className, div, img) {
        this._name = name;
        this._damage = damage;
        this._className = className;
        this._div = div;
        this._img = img;
    }
}